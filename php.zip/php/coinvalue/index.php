<?php 

require("phpmailer/PHPMailer.php"); 
require("phpmailer/Exception.php"); 
require("phpmailer/SMTP.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex,nofollow">
	<meta name="viewport" content="user-scalable=no">
    <link rel="stylesheet" href="css/general.css">
    <link rel="stylesheet" href="css/all.css">
	<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
	<title>CoinValue</title>
</head>
<body>
	<a href="main"><div id="homeButton"><i class="fa-solid fa-coins"></i></div></a>
	<a href="data"><div id="dataButton"><i class="fa-solid fa-calendar"></i></div></a>
	<a href="barres"><div id="barresButton"><i class="fa-solid fa-chart-column"></i></div></a>
	<a href="dates"><div id="datesButton"><i class="fa-solid fa-calendar-plus"></i></div></a>
	<a href="xy"><div id="xyButton"><i class="fa-solid fa-chart-line"></i></div></a>
	<a href="info"><div id="infoButton"><i class="fa-solid fa-circle-info"></i></div></a>
	<a href="contacte"><div id="contacteButton"><i class="fa-solid fa-envelope"></i></div></a>
	<div style="height:14vw;"></div>
<?php 
	$nom = $_GET['nom'];
	$email = $_GET['email'];
	$comentaris = $_GET['comentaris'];
	$mail = new PHPMailer();
	$mail->isSMTP();
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 587;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = 'tls';
	$mail->Username = "noreplylohder@gmail.com";
	$mail->Password = "****************";
	$mail->setFrom("noreplylohder@gmail.com","lohder (Coin Value)");
	$mail->addReplyTo("noreplylohder@gmail.com","lohder (Coin Value)");
	$mail->isHTML(true);	
	$mail->CharSet = 'UTF-8';
	$mail->addAddress($email);
	$mail->Subject = "Coin Value";
	$mail->Body = "Estimat/estimada ".$nom.", des de Coin Value prenem nota dels seus comentaris:<br>".
		"<br>\" ".$comentaris." \"<br><br>Moltes gràcies.";

	if (!$mail->send()){
		echo "<h2>Error d'enviament. Torni a intentarho.</h2>";
		?><!-- <script>alert("Error en l'enviament de mail. Intentiho de nou.");</script> --><?php
	}else{
		echo "<h2>Comentaris enviats correctament.</h2>";
		?><!-- <script>alert("Email enviat correctament.");</script> --><?php
	}	
?>
</body>
</html>

