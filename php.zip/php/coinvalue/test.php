<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex,nofollow">
	<meta name="viewport" content="user-scalable=no">
    <link rel="stylesheet" href="css/general.css">
    <link rel="stylesheet" href="css/all.css">
	<title>CoinValue TEST</title>
</head>
<body>
	<form action="index" method="GET">
        <label>Nom</label><br>
        <input type="text" name="nom" required="required"><br>	   
        <label>Email de contacte</label><br>
        <input type="email" name="email" required="required"><br>
        <label>Comentaris</label><br>
		<textarea name="comentaris" cols="30" rows="4"></textarea><br><br>
		<input type="submit" name="submit" value="Enviar Comentaris">
	</form>

	<div id="currenciesJson" style="display:none"></div>
	<div><p id="currenciesText">Coin Value és un aplicatiu per visualitzar el valor de les principals divises que utilitza dades actualitzades a través de l'API Frankfurter. Aquesta alhora es nodreix de dades facilitades pel mateix Banc Central Europeu.</p></div>

<script>

	fetch('https://api.frankfurter.app/currencies', {method:'GET',headers:{'Accept':'application/json'}})
    	.then(response => response.text())
    	.then(text => { 
    			document.getElementById("currenciesJson").innerText = text;
    			json = JSON.parse(document.getElementById("currenciesJson").innerText);
    			var ara = new Date().toLocaleDateString('ca-es', {year:"numeric",month:"numeric",day:"numeric"});
    			var currenciesText = "\n\nA data "+ara+" la llista de divises en ús per l'API Frankfurter i en conseqüència a Coin Value és la següent: \n\n";
    			for ([key,value] of Object.entries(json)){
  					currenciesText += key + ": " + value + "\n";
				}
				nova=currenciesText;
				document.getElementById("currenciesText").innerText += currenciesText;
    		}
    	);
    	
</script>



</body>
</html>
