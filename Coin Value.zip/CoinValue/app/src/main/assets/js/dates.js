function setData(){
    data = new Date();
    any = data.getFullYear();
    mes = pad(data.getMonth()+1,2);
    dia = pad(data.getDate(),2);
    avui = any + "-" + mes + "-" + dia;
    document.getElementById("data2").value = avui;
    data2 = new Date(data.getTime());
    data2.setDate(data.getDate()-30);
    anyPrevi = data2.getFullYear();
    mesPrevi = pad(data2.getMonth()+1,2);
    diaPrevi = pad(data2.getDate(),2);
    previ = anyPrevi + "-" + mesPrevi + "-" + diaPrevi;
    document.getElementById("data").value = previ;
}
function setAmount(){
    amount = parseFloat(urlParams.get("amount"));
    document.getElementById("amount").innerHTML = "Quantitat: " + amount;
    return amount;
}
function setReferencia(){
    referencia = urlParams.get("referencia");
    document.getElementById("referencia").innerHTML = "Referència: " + referencia;
    return referencia;
}

function getValorsDatesReferencia(){
    colorlist = ["green", "dodgerblue", "lightcoral", "darkorange",
        "mediumorchid", "red", "hotpink", "seagreen",
        "salmon", "lightskyblue", "olivedrab", "mediumpurple",
        "lightseagreen", "goldenrod", "lightsalmon", "indianred",
        "deepskyblue","forestgreen","mediumslateblue","orchid",
        "brown","cadetblue","chocolate","crimson",
        "darkgoldenrod","darkcyan","darkolivegreen","darkviolet",
        "purple","teal","violet","peru"];
    divises = JSON.parse(urlParams.get("divises"));
    divisesParam = "";
    primera = true;
    for ([key] of Object.entries(divises)){
        if (primera){
            divisesParam += key;
            primera = false;
        }else{
            divisesParam += "," + key;
        }
    }
    url = "https://api.frankfurter.app/" + document.getElementById("data").value + ".." +
        document.getElementById("data2").value + "?amount=" + amount + "&from=" +
        referencia + "&to=" + divisesParam;
    peticio.open("GET",url);
    peticio.send();
    peticio.onreadystatechange = function(){
        if (this.readyState==4 && this.status==200){
            json = JSON.parse(peticio.responseText);
            rates = json.rates;
            numeroDeDates = Object.keys(rates).length;
            numeroDeDivises = Object.keys(rates[Object.keys(rates)[0]]).length;
            dates = [];
            nomsMonedes = new Array(numeroDeDivises);
            monedes = new Array(numeroDeDivises);
            for (i=0; i<numeroDeDivises; i++){
                monedes[i] = new Array(numeroDeDates);
            }
            i=0; j=0;
            for ([data,valors] of Object.entries(rates)){
                dates.push(data);
                for ([divisa,valor] of Object.entries(valors)){
                    nomsMonedes[i] = divisa;
                    monedes[i][j] = valor;
                    i++;
                }
                i = 0; j++;
            }

            // INICIALITZEM LA TAULA
            document.getElementById("laTaula").innerHTML = "";
            document.getElementById("laTaula").innerHTML = "<tr id=\"headersRow\"></tr>";

            // PRIMERA FILA DE LA TAULA (DIVISES)
            txt = "<th>DATES</th>";
            for (i=0; i<numeroDeDivises; i++){
                txt += "<th>" + nomsMonedes[i] + "</th>";
            }
            document.getElementById("headersRow").innerHTML = txt;

            // SEGUENTS FILES DE LA TAULA
            txt = "";
            for (i=0; i<dates.length; i++){
                txt += "<tr>";
                txt += "<td class=\"dates\">" + dates[i] + "</td>";
                for (j=0; j<monedes.length; j++){
                    txt += "<td>" + monedes[j][i] + "</td>";
                }
                txt += "</tr>";
            }
            document.getElementById("laTaula").innerHTML += txt;

        }
    }
}

function pad(num,size){
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}