function setData(){
    data = new Date();
    any = data.getFullYear();
    mes = pad(data.getMonth()+1,2);
    dia = pad(data.getDate(),2);
    avui = any + "-" + mes + "-" + dia;
    document.getElementById("data2").value = avui;
    data2 = new Date(data.getTime());
    data2.setDate(data.getDate()-30);
    anyPrevi = data2.getFullYear();
    mesPrevi = pad(data2.getMonth()+1,2);
    diaPrevi = pad(data2.getDate(),2);
    previ = anyPrevi + "-" + mesPrevi + "-" + diaPrevi;
    document.getElementById("data").value = previ;
}
function setAmount(){
    amount = parseFloat(urlParams.get("amount"));
    document.getElementById("amount").innerHTML = "Quantitat: " + amount;
    return amount;
}
function setReferencia(){
    referencia = urlParams.get("referencia");
    document.getElementById("referencia").innerHTML = "Referència: " + referencia;
    return referencia;
}

function getValorsDatesReferencia(){
    colorlist = ["green", "dodgerblue", "lightcoral", "darkorange",
        "mediumorchid", "red", "hotpink", "seagreen",
        "salmon", "lightskyblue", "olivedrab", "mediumpurple",
        "lightseagreen", "goldenrod", "lightsalmon", "indianred",
        "deepskyblue","forestgreen","mediumslateblue","orchid",
        "brown","cadetblue","chocolate","crimson",
        "darkgoldenrod","darkcyan","darkolivegreen","darkviolet",
        "purple","teal","violet","peru"];
    divises = JSON.parse(urlParams.get("divises"));
    divisesParam = "";
    primera = true;
    for ([key] of Object.entries(divises)){
        if (primera){
            divisesParam += key;
            primera = false;
        }else{
            divisesParam += "," + key;
        }
    }
    url = "https://api.frankfurter.app/" + document.getElementById("data").value + ".." +
        document.getElementById("data2").value + "?amount=" + amount + "&from=" +
        referencia + "&to=" + divisesParam;
    peticio.open("GET",url);
    peticio.send();
    peticio.onreadystatechange = function(){
        if (this.readyState==4 && this.status==200){
            json = JSON.parse(peticio.responseText);
            rates = json.rates;
            numeroDeDates = Object.keys(rates).length;
            numeroDeDivises = Object.keys(rates[Object.keys(rates)[0]]).length;
            dates = [];
            nomsMonedes = new Array(numeroDeDivises);
            monedes = new Array(numeroDeDivises);
            for (i=0; i<numeroDeDivises; i++){
                monedes[i] = new Array(numeroDeDates);
            }
            i=0; j=0;
            for ([data,valors] of Object.entries(rates)){
                dates.push(data);
                for ([divisa,valor] of Object.entries(valors)){
                    nomsMonedes[i] = divisa;
                    monedes[i][j] = valor;
                    i++;
                }
                i = 0; j++;
            }
            auxDatasets = new Array(numeroDeDivises);
            for (i=0; i<numeroDeDivises; i++){
                auxDataset = {label:"",data:[],borderColor:"",fill:false};
                auxDataset.label = nomsMonedes[i];
                auxDataset.data = monedes[i];
                auxDataset.borderColor = colorlist[i];
                auxDatasets[i] = auxDataset;
            }

            // LLEGENDA
            txt = "";
            for (i=0; i<numeroDeDivises; i++){
                txt += "<span style=\"color:" + colorlist[i] + ";font-weight:bold;\">" + nomsMonedes[i] + "&nbsp&nbsp" + "</span>";
            }
            document.getElementById("llegenda").innerHTML = txt + "<br>";

            // GRAFICA
            new Chart("myChart", {
                type: "line",
                data: { labels:dates, datasets:auxDatasets },
                options: { legend: {display: false} }
            });

        }
    }
}

function pad(num,size){
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}