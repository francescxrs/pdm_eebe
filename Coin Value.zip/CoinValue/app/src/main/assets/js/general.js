function appearDisappear(div,displ){

	var element = document.getElementById(div);
	var display = window.getComputedStyle(element, null).getPropertyValue("display");

	if (display != "none"){
		element.style.display = "none";
	}else{
		element.style.display = displ;
	}

}

function switchDivDisplay(div1,div2,disp1,disp2){

	var element = document.getElementById(div1);
	var display = window.getComputedStyle(element, null).getPropertyValue("display");

	if (display != "none"){
		document.getElementById(div1).style.display = "none";
		document.getElementById(div2).style.display = disp2;
	}else{
		document.getElementById(div1).style.display = disp1;
		document.getElementById(div2).style.display = "none";
	}

}

function hideFloatingElement(id,disp1){

	var element = document.getElementById(id);
	var display = window.getComputedStyle(element, null).getPropertyValue("display");

	if (display != "none"){
		document.getElementById(id).style.display = "none";
	}else{
		document.getElementById(id).style.display = disp1;
	}

}