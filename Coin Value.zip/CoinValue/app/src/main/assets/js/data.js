function setData(){
    data = new Date();
    any = data.getFullYear();
    mes = pad(data.getMonth()+1,2);
    dia = pad(data.getDate(),2);
    avui = any + "-" + mes + "-" + dia;
    document.getElementById("data").value = avui;
}
function setAmount(){
    amount = parseFloat(urlParams.get("amount"));
    document.getElementById("amount").innerHTML = "Quantitat: " + amount;
    return amount;
}
function setReferencia(){
    referencia = urlParams.get("referencia");
    document.getElementById("referencia").innerHTML = "Referència: " + referencia;
    return referencia;
}

function getValorsReferencia(){
    text = "";
    divises = JSON.parse(urlParams.get("divises"));
    url = "https://api.frankfurter.app/" + document.getElementById("data").value +
        "?amount=" + amount + "&from=" + referencia;
    peticio.open("GET",url);
    peticio.send();
    peticio.onreadystatechange = function(){
        if (this.readyState==4 && this.status==200){
            json = JSON.parse(peticio.responseText);
            rates = json.rates;
            for ([key,value] of Object.entries(rates)){
                if (divises.hasOwnProperty(key)) text += key + ": " + value + "<br>";
            }
            document.getElementById("divises").innerHTML = text;
        }
    }
}

function pad(num,size){
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}