package net.ddns.lohder;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class DBManager {

    private Context context;
    private SQLiteDatabase database;
    private SQLiteHelper dbHelper;

    public DBManager(Context c) {
        this.context = c;
    }

    public DBManager open() throws SQLException {
        this.dbHelper = new SQLiteHelper(this.context);
        this.database = this.dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        this.dbHelper.close();
    }

    public void insertRegistreConfiguracio() {
        ContentValues contentValue = new ContentValues();
        contentValue.put("amount",1.00);
        contentValue.put("referencia","EUR");
        contentValue.put("divises","{\"USD\":\"\"}");
        this.database.insert("configuracio", null, contentValue);
    }
    public void deleteRegistresConfiguracio(){
        this.database.execSQL("DELETE FROM configuracio");
    }

    public int updateRegistreConfiguracio(int id, Double amount, String referencia, String divises) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("amount", amount);
        contentValues.put("referencia", referencia);
        contentValues.put("divises", divises);
        return this.database.update("configuracio", contentValues, "id="+id, null);
    }
    public Cursor fetchLastRowConfiguracio() {
        Cursor cursor = this.database.rawQuery("SELECT * FROM configuracio ORDER BY ROWID DESC LIMIT 1", null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

}
