package net.ddns.lohder;

import android.content.Context;
import android.database.Cursor;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.apache.commons.codec.binary.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class URLInterceptor extends WebViewClient{

    private Context context;

    public URLInterceptor(Context c) {
        this.context = c;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url){

        DBManager dbm = new DBManager(context);
        dbm.open();

        /* FIELDS: 0 Id, 1 Amount, 2 Referencia, 3 Divises  */

        if (dbm.fetchLastRowConfiguracio().getCount()==0){
            dbm.insertRegistreConfiguracio();
            Toast.makeText(context, "BDD buida, registre default insertat.", Toast.LENGTH_SHORT).show();
        }

        if (url.contains("main")){
            view.loadUrl(encodeString("file:///android_asset/main.html" + getParams(dbm)));
            return true;
        }else if (url.contains("data")){
            view.loadUrl(encodeString("file:///android_asset/data.html" + getParams(dbm)));
            return true;
        }else if (url.contains("barres")){
            view.loadUrl(encodeString("file:///android_asset/barres.html" + getParams(dbm)));
            return true;
        }else if (url.contains("dates")){
            view.loadUrl(encodeString("file:///android_asset/dates.html" + getParams(dbm)));
            return true;
        }else if (url.contains("xy")){
            view.loadUrl(encodeString("file:///android_asset/xy.html" + getParams(dbm)));
            return true;
        }else if (url.contains("info")){
            view.loadUrl("file:///android_asset/info.html");
            return true;
        }else if (url.contains("contacte")){
            view.loadUrl("file:///android_asset/contacte.html");
            return true;
        }else if (url.contains("actualitza")){
            String queryString = decodeString(url);
            String[] s = queryString.split("&");
            Double amount = Double.parseDouble(s[0].split("=")[1]);
            String referencia = s[1].split("=")[1];
            String divises = s[2].split("=")[1];
            updateRegistreConfiguracio(dbm,amount, referencia, divises);
            String params =
                    "?amount=" + amount.toString() +
                    "&referencia=" + referencia +
                    "&divises=" + divises;
            String ruta = encodeString("file:///android_asset/main.html" + params);
            //Toast.makeText(context, ruta, Toast.LENGTH_SHORT).show();
            view.loadUrl(ruta);
            return true;
        }else if (url.contains("elimina")){
            deleteRegistresConfiguracio(dbm);
            insertRegistreConfiguracio(dbm);
            String params =
                "?amount=" + getDoubleFieldConfiguracio(dbm,1).toString() +
                "&referencia=" + getStringFieldConfiguracio(dbm,2) +
                "&divises=" + getStringFieldConfiguracio(dbm,3);
            String ruta = encodeString("file:///android_asset/main.html" + params);
            //Toast.makeText(context, "Delete Fet", Toast.LENGTH_SHORT).show();
            //Toast.makeText(context, ruta, Toast.LENGTH_SHORT).show();
            view.loadUrl(ruta);
            return true;
        }else{
            return false;
        }

    }

    //  CODIFICAR I DECODIFICAR URL STRINGS
    public String encodeString(String rawString){
        byte[] bytes = StringUtils.getBytesUtf8(rawString);
        return StringUtils.newStringUtf8(bytes);
    }
    public String decodeString(String encodedString){
        try {
            return URLDecoder.decode(encodedString, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }

    // VALORS DE TAULA CONFIGURACIO
    public int getIntFieldConfiguracio(DBManager dbm, int i){
        int field = 0;
        Cursor cursor = dbm.fetchLastRowConfiguracio();
        int cgc = cursor.getCount();
        if (cgc == 1) field = cursor.getInt(i);
        return field;
    }
    public String getStringFieldConfiguracio(DBManager dbm, int i){
        String field = "";
        Cursor cursor = dbm.fetchLastRowConfiguracio();
        int cgc = cursor.getCount();
        if (cgc == 1) field = cursor.getString(i);
        return field;
    }
    public Double getDoubleFieldConfiguracio(DBManager dbm, int i){
        Double field = 1.00;
        Cursor cursor = dbm.fetchLastRowConfiguracio();
        int cgc = cursor.getCount();
        if (cgc == 1) field = cursor.getDouble(i);
        return field;
    }

    // CRUD TAULA CONFIGURACIO
    public void updateRegistreConfiguracio(DBManager dbm, Double amount, String referencia, String divises){
        dbm.updateRegistreConfiguracio(getIntFieldConfiguracio(dbm,0), amount,referencia,divises);
    }
    public void deleteRegistresConfiguracio(DBManager dbm){
        dbm.deleteRegistresConfiguracio();
    }
    public void insertRegistreConfiguracio(DBManager dbm){
        dbm.insertRegistreConfiguracio();
    }

    // QUERY PARAMS
    public String getParams(DBManager dbm){
        return "?amount=" + getDoubleFieldConfiguracio(dbm,1).toString() +
            "&referencia=" + getStringFieldConfiguracio(dbm,2) +
            "&divises=" + getStringFieldConfiguracio(dbm,3);
    }


}
