package net.ddns.lohder;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.apache.commons.codec.binary.StringUtils;

public class URLInterceptor extends WebViewClient{

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url){
        if (url.contains("main")){
            String params = "?parametre=Paràmetre Java String passat al WebView com a variable Javascript.";
            String ruta = "file:///android_asset/main.html";
            ruta = ruta + params;
            ruta = encodeString(ruta);
            view.loadUrl(ruta);
            return true;
        }else if (url.contains("data")){
            view.loadUrl("file:///android_asset/data.html");
            return true;
        }else if (url.contains("barres")){
            view.loadUrl("file:///android_asset/barres.html");
            return true;
        }else if (url.contains("dates")){
            view.loadUrl("file:///android_asset/dates.html");
            return true;
        }else if (url.contains("xy")){
            view.loadUrl("file:///android_asset/xy.html");
            return true;
        }else if (url.contains("info")){
            view.loadUrl("file:///android_asset/info.html");
            return true;
        }else if (url.contains("contacte")){
            view.loadUrl("file:///android_asset/contacte.html");
            return true;
        }else{
            return false;
        }
    }

    public String encodeString(String rawString){
        byte[] bytes = StringUtils.getBytesUtf8(rawString);
        String utf8EncodedString = StringUtils.newStringUtf8(bytes);
        return utf8EncodedString;
    }

}
