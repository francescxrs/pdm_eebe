package net.ddns.lohder;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.apache.commons.codec.binary.StringUtils;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // INSTANCIEM EL HELPER, QUE CREA/ACCEDEIX A LA BDD
        SQLiteHelper helper = new SQLiteHelper(MainActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();

        // INSTANCIEM EL MANAGER, DES D'ON FAREM ACCIONS CRUD
        DBManager dbm = new DBManager(MainActivity.this);
        dbm.open();

        // SOLICITEM ULTIM REGISTRE
        Cursor cursor = dbm.fetchLastRowConfiguracio();

        // SI EL REGISTRE EXISTEIX NO CAL SOBREESCRIURE CONFIGURACIO PER DEFECTE
        int cgc = cursor.getCount();
        //Toast.makeText(MainActivity.this, "CURSOR GET COUNT: " + Integer.toString(cgc),Toast.LENGTH_LONG).show();
        if (cgc==0) {
            dbm.insertRegistreConfiguracio();
            //Toast.makeText(MainActivity.this, "CONFIG DEFAULT AFEGIDA",Toast.LENGTH_LONG).show();
        }else{
            //Toast.makeText(MainActivity.this, "CONFIG DEFAULT EXISTENT",Toast.LENGTH_LONG).show();
        }

        // OBTENIM ELS PARAMETRES DE CONFIGURACIO
        cgc = cursor.getCount();
        int id = 1;
        String amount = Double.toString(1.00);
        String referencia = "EUR";
        String divises = "{\"USD\":\"\"}";
        if (cgc == 1){
            id = cursor.getInt(0);
            amount = Double.toString(cursor.getDouble(1));
            referencia = cursor.getString(2);
            divises = cursor.getString(3);
            //Toast.makeText(MainActivity.this, "ID: " + Integer.toString(id) + ", REFERENCIA:" + referencia + ", DIVISES: " + divises , Toast.LENGTH_LONG).show();
        }

        // CREEM LA REFERENCIA AL WEBVIEW (EN OBRIR L'APP)
        WebView webView = (WebView) findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new URLInterceptor(MainActivity.this));
        webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        String params = "?amount=" + amount + "&referencia=" + referencia + "&divises=" + divises;
        webView.loadUrl(encodeString("file:///android_asset/main.html" + params));

    }

    public String encodeString(String rawString){
        byte[] bytes = StringUtils.getBytesUtf8(rawString);
        String utf8EncodedString = StringUtils.newStringUtf8(bytes);
        return utf8EncodedString;
    }

}